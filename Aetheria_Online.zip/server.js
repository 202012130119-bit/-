const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const WebSocket = require("ws");

const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const rooms = new Map();
const clients = new Map();

function roomCode() {
  let code;
  do { code = String(Math.floor(100000 + Math.random() * 900000)); } while (rooms.has(code));
  return code;
}
function send(ws, msg) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(msg));
}
function broadcast(room, msg) {
  for (const id of room.players) {
    const ws = clients.get(id);
    if (ws) send(ws, msg);
  }
}
function state(room) {
  return {
    type: "ROOM_STATE",
    roomCode: room.code,
    trackName: room.trackName,
    difficulty: room.difficulty,
    keyMode: room.keyMode,
    players: [...room.players].map(id => {
      const p = room.info.get(id);
      return { id, name: p.name, ready: !!p.ready, score: p.score || 0 };
    })
  };
}
function leave(ws) {
  const id = ws.playerId;
  const room = ws.roomCode && rooms.get(ws.roomCode);
  clients.delete(id);
  if (!room) return;
  room.players = room.players.filter(x => x !== id);
  room.info.delete(id);
  if (room.players.length === 0) {
    rooms.delete(room.code);
    return;
  }
  broadcast(room, { type: "ROOM_CLOSED", reason: "opponent_left" });
  rooms.delete(room.code);
}

const server = http.createServer((req, res) => {
  let p = req.url.split("?")[0];
  if (p === "/") p = "/Aetheria_Online.html";
  const file = path.join(ROOT, p);
  if (!file.startsWith(ROOT)) { res.writeHead(403); return res.end("Forbidden"); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end("Not Found"); }
    const ext = path.extname(file);
    const type = ext === ".html" ? "text/html; charset=utf-8" : "application/octet-stream";
    res.writeHead(200, { "Content-Type": type, "Cache-Control": "no-store" });
    res.end(data);
  });
});

const wss = new WebSocket.Server({ server });
wss.on("connection", ws => {
  const id = crypto.randomUUID();
  ws.playerId = id;
  clients.set(id, ws);
  send(ws, { type: "WELCOME", playerId: id });

  ws.on("message", raw => {
    let m;
    try { m = JSON.parse(raw.toString()); } catch { return; }

    if (m.type === "CREATE_ROOM") {
      if (ws.roomCode) return;
      const code = roomCode();
      const room = {
        code, hostId: id, players: [id], info: new Map(),
        trackName: String(m.trackName || ""), difficulty: String(m.difficulty || "NORMAL"),
        keyMode: Number(m.keyMode || 4), chart: m.chart || m.chartData || null
      };
      room.info.set(id, { name: String(m.name || "Player").slice(0,16), ready:false, score:0 });
      rooms.set(code, room);
      ws.roomCode = code;
      send(ws, { type:"ROOM_CREATED", roomCode:code });
      broadcast(room, state(room));
      return;
    }

    if (m.type === "JOIN_ROOM") {
      const room = rooms.get(String(m.roomCode || ""));
      if (!room) return send(ws, {type:"ROOM_ERROR", message:"ルームが見つかりません。"});
      if (room.players.length >= 2) return send(ws, {type:"ROOM_ERROR", message:"このルームは満員です。"});
      if (String(m.trackName || "") !== room.trackName) {
        return send(ws, {type:"ROOM_ERROR", message:`曲が一致しません。ホストの曲: ${room.trackName}`});
      }
      if (Number(m.keyMode || 4) !== room.keyMode || String(m.difficulty || "") !== room.difficulty) {
        return send(ws, {type:"ROOM_ERROR", message:"KEY MODEまたは難易度が一致していません。"});
      }
      room.players.push(id);
      room.info.set(id, { name:String(m.name || "Player").slice(0,16), ready:false, score:0 });
      ws.roomCode = room.code;
      send(ws, {type:"ROOM_JOINED", roomCode:room.code});
      if (room.chart) send(ws, {type:"CHART_SYNC", chart:room.chart});
      broadcast(room, state(room));
      return;
    }

    const room = ws.roomCode && rooms.get(ws.roomCode);
    if (!room) return send(ws, {type:"ROOM_ERROR", message:"ルームに参加していません。"});

    if (m.type === "READY") {
      const p = room.info.get(id); if (!p) return;
      p.ready = true;
      broadcast(room, state(room));
      if (room.players.length === 2 && room.players.every(x => room.info.get(x)?.ready)) {
        const startAt = Date.now() + 5000;
        room.started = true;
        room.startAt = startAt;
        broadcast(room, {type:"MATCH_START", startAt, serverNow:Date.now()});
      }
      return;
    }

    if (m.type === "PLAYER_UPDATE") {
      const p = room.info.get(id); if (!p) return;
      p.score = Number(m.score || 0);
      p.combo = Number(m.combo || 0);
      broadcast(room, {
        type:"PLAYER_UPDATE", playerId:id, name:p.name,
        score:p.score, combo:p.combo, maxCombo:Number(m.maxCombo||0),
        perfect:Number(m.perfect||0), great:Number(m.great||0), miss:Number(m.miss||0)
      });
      return;
    }

    if (m.type === "PLAYER_FINISH") {
      const p = room.info.get(id);
      broadcast(room, {type:"PLAYER_FINISH", playerId:id, name:p?.name || "Player", score:Number(m.score||0), maxCombo:Number(m.maxCombo||0)});
      return;
    }
  });

  ws.on("close", () => leave(ws));
});

server.listen(PORT, () => {
  console.log(`Aetheria Online server: http://localhost:${PORT}`);
});
